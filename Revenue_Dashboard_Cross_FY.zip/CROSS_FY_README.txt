Cross-fiscal-year revenue comparison

Open Revenue Dashboard.pbip in Power BI Desktop and refresh.
Default comparison: 2027 Plan v2 / FY27 versus 2026.11 Forecast / FY26.
Current FY and Prior FY controls are added to Executive, Corp, Alumina and Aluminum.
Existing shared fiscal-year slicers continue to control other visuals.
Bridge revenue measures use full-year totals; Executive Q4 uses Q4 of each selected year.
Executive measures include Actual, Current Forecast and Plan scenarios.
Version dimension includes both revenue and metals versions.
No source amount transformations were changed.

Validation: JSON parsing and model reference checks performed. Power BI refresh and DAX execution require your connected Desktop environment.
Price-per-tonne volume denominators retain their existing logic; cross-year revenue changes do not establish cross-year price-per-tonne comparability.
