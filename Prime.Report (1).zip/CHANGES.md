# Prime project corrections — 14 October 2026

Open `Prime.pbip` in Power BI Desktop and refresh using your existing SharePoint credentials. The ZIP includes the report and semantic model. Local caches/settings are excluded so the edited model can be rebuilt.

## Implemented
- Weighted MOI in $/mt: sum of quantity × row MOI divided by quantity for rows with nonblank MOI and quantity. Zero margins remain valid; missing margins do not depress the average.
- Customer rankings use one volume-based Top 9 with alphabetical tie-breaking. Others uses the remaining eligible customers and weighted MOI. Long and blank customer groups are excluded consistently with the existing customer axis. Netback ranking helper measures use this same population.
- Sales Profile and customer Volume/Margin matrix use the year of Current_Slicer[Version]. 2026.10 returns 2026 only. Prior/future years and cross-year totals return blank; Power BI may hide blank columns. No historical version selection is inferred.
- Completed months already present in the selected forecast remain unchanged; there is no separate actuals splice.
- The previously empty customer matrix now has customer-group rows, year columns, volume in mt, and MOI in $/mt.
- Price Structure percentages use sum(LME) or sum(Regional Premium) by QP category divided by the corresponding component total in the current report context. These are direct column-sum shares, not quantity-weighted shares. LME and regional calculations use their own QP mappings. Mapping falls back to the raw QP; empty QP is Unknown, nonstandard QP is Others. Each available component subtotal is 100%; no combined LME/regional percentage is shown.
- Price Structure volume now follows the same QP category rather than repeating total volume in each row.
- LME and Regional Premium model columns are numeric. Power Query converts nonnumeric/unavailable values to null; review unexpected source placeholders during refresh.
- Corrected the Sales Profile syntax/missing-table references, commercial revenue row label, broken title measure reference, MOI unit label, and chronological month key.
- Ecolum remains blank pending an agreed source classification; unavailable data is not represented by a hardcoded zero.

## Validation
- All report JSON files parsed successfully; no missing report measure bindings found.
- Checked measure parentheses and business-rule examples for weighted Others, ranking reconciliation, selected year, QP share arithmetic and chronological sorting.
- No Power BI/DAX engine execution or SharePoint refresh was available. These checks are not a substitute for Desktop validation.

## Desktop checks
1. Select 2026.10 and confirm 2026 values in both annual matrices; other years must not repeat 2026.
2. Filter region/product and confirm identical Top 9 names/order for volume and MOI; Others must reconcile on volume.
3. Check MOI against a small quantity-weighted sample; confirm $/mt.
4. Expand each price component; available QP shares should total 100% independently.
5. Inspect numeric source conversion and verify that missing prices remain blank.

Historical actuals mapping will be added when historical data and its version convention are supplied.
