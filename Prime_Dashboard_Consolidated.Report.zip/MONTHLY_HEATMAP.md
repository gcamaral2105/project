# Monthly volume variance heatmap

Added to the bottom of Prime Summary. Rows use MonthYearShort sorted chronologically. Columns show current vs plan and current vs previous volume variance as percentages with one decimal.

Both columns use the same continuous scale: -20% red (#D6604D), 0% white, +20% blue (#4393C3); more extreme values retain endpoint colors. Blank current/comparison data and zero-denominator comparisons remain blank. Colors indicate direction, not business favorability.

The heatmap uses the consolidated project's existing version and volume measures and applicable page filters. The special Product Mapping slicer remains limited to Netback per Customer and Top 10 Customers Volume; it does not filter the heatmap.

Corrected the calendar sorting key to Year * 100 + Month. Existing measures and visuals are otherwise preserved, except page height extended to fit the new matrix. No missing features from older project versions have been reapplied.

Validated JSON, measure references, color endpoints, and date-sort examples. Power BI Desktop rendering, DAX execution and SharePoint refresh were not available. Open the included PBIP and refresh to verify. If your Desktop version does not display the background formatting, set each value column's conditional background to Field value using Heatmap Plan Color or Heatmap Previous Color respectively.
