# Product Mapping slicer

Added a dropdown above the KPI cards, initially showing all products. Supports multiple product mappings.

It filters only:
- Netback per Customer (table).
- Top 10 Customers Volume (kmt) (volume bar chart).

Interactions with all other existing visuals and slicers are disabled for this slicer, including the neighboring customer margin chart. Existing page-wide filters still intersect the selected products. Rankings recalculate using the filtered data; existing ranking measures are unchanged.

Based on the uploaded consolidated project. All semantic-model files and preexisting visual files are preserved unchanged. Only a new slicer and page interaction settings were added. Price Exposure calculations were not changed in this update.

Validation: JSON parsed; exactly two outgoing DataFilter interactions, all other targets NoFilter; original semantic model and visuals checked for byte equality. Power BI Desktop rendering and interaction execution remain unverified.

Extract the ZIP, open the included PBIP project and verify both target visuals change when selecting P1020 or another product, while KPI cards and other visuals do not.
