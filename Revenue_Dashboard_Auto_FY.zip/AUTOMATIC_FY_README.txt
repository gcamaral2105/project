Automatic fiscal-year comparison

Extract all files, open Revenue Dashboard.pbip and refresh in Power BI Desktop.
Choose the current and prior versions. Each revenue comparison uses FY + characters 3 and 4 of the selected VersionID.
Example: 2027 Plan v2 / FY27 versus 2026.11 Forecast / FY26.
The two comparison FY slicers and their tables have been removed. The previous page dimensions and visual positions have been restored.
The original shared fiscal-year slicer remains for other charts.
Bridge revenue, Executive annual, Q4, component and FY label measures use automatic FY selection.
Plan scenario support and combined revenue/metals version list are retained.
This assumes version names begin with a four-digit year. It does not support choosing another reporting year inside a version.
Price-per-tonne volume denominators retain their existing logic.
Validation: JSON and reference checks performed. Power BI refresh and DAX execution were not available.
