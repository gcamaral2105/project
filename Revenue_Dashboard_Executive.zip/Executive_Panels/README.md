# Executive business-area panels

Open Revenue Dashboard.pbip in Power BI Desktop. Go to Executive and scroll below the overview charts. Select one Current Forecast, one Previous Forecast and one Fiscal Year using the existing slicers. Refresh the model if Power BI prompts you to do so.

## What changed
- Three Deneb panels added at y=700: Alumina & Bauxite, Aluminum & Energy, Corporate & Eliminations.
- Existing lower visuals moved down 470px; page height increased to 1730px. Existing top overview and all other pages retained.
- Added the disconnected d_ExecutiveComponents table and 16 measures in the Executive Panels display folder.
- Each panel shows FY current revenue, Q4 current revenue, percentage changes versus the prior version, the main driver and paired prior/current component columns.

## Calculation rules
- FY follows the selected fiscal year; Q4 is QuarterNumber=4 in that year. These are full-year outlooks including Actual and Current Forecast rows, not forecast-only remaining months.
- Version, snapshot, calendar, scenario, period, revenue-category and business-area filters are explicitly controlled by these panel measures. Other fact attributes remain filterable. Panels use the slicer-selected versions and FY, and ignore quarter selections for FY totals.
- Percent change = (current - prior) / ABS(prior). Prior=0 returns blank. Green means increased revenue / less-negative corporate revenue; red means decreased revenue. This convention applies only to the new panels.
- Main driver = largest absolute FY dollar movement, with alphabetical tie-breaking. For Alumina, API + Alumina premium + Aa Others are grouped as Alumina Product Revenue. Bauxite and residual other components are separate driver candidates. Other areas use their component groups. No movement shows No change.
- Other components is the residual of every source revenue category not explicitly listed for that area. Its chart bar appears when nonzero (greater than $0.50 in absolute value) in either version. Header totals include all source categories.
- FY and Q4 totals display USD bn. Alumina and Corporate component charts display USD M; Aluminum displays USD bn. Driver movements display USD M.
- A missing category in one version contributes zero for driver comparisons; missing whole-period totals or ambiguous slicer selections leave KPI comparisons blank.

## Validation and limitations
All report JSON and embedded Vega specs were parsed. The three Vega specs were rendered with illustrative positive/negative data. Existing-file comparisons verified that other report pages were unchanged. DAX has not been executed in Power BI / Analysis Services here; refresh and check source totals in Desktop before publishing. Existing d_version is still based on f_metals, so revenue-only versions absent from that table will not appear in the slicers.

## Quick checks in Desktop
1. Confirm a single version in each slicer and one FY.
2. Compare each panel FY total to a matrix summing AmountUSD for that area, version, FY and Actual/Current Forecast scenarios.
3. Repeat for QuarterNumber=4.
4. Sum the chart components including Other components; verify reconciliation with the FY total.
5. Confirm prior/current legend labels change when you change slicers.
6. For Corporate moving from -300M to -250M, expect +50M / +16.7%.

The standalone Vega JSON files and DAX definitions are included for maintenance. Do not re-add the measures: they are already installed in this project.
